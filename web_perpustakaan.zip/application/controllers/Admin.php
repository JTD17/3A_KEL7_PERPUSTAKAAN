<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('cart');
        $this->load->model('Perpus_model');
        $this->load->library('form_validation');
        if (empty($this->session->userdata('admin'))) {
            redirect('');
        }
    }
    public function index()
    {
        //$data['user'] = $this->db->get_where('pegawai', ['username_pegawai' => $this->session->userdata('username')])->row_array();
        //echo 'Selamat Datang ' . $data['user']['nama_pegawai'];
        //$this->load->view('templates/header', $data);
        $data['admin'] = $this->db->count_all_results('pegawai');
        $data['anggota'] = $this->db->count_all_results('anggota');
        $data['detail'] = $this->db->count_all_results('detail_transaksi');
        $data['buku'] = $this->db->count_all_results('buku');
        $data['penulis'] = $this->db->count_all_results('penulis');
        $data['penerbit'] = $this->db->count_all_results('penerbit');
        $data['kategori'] = $this->db->count_all_results('kategori');
        $data['rak'] = $this->db->count_all_results('rak');
        $data['menunggu'] = $this->db->where('status', 'Menunggu')->from("detail_transaksi")->count_all_results();
        $data['pinjam'] = $this->db->where('status', 'Dipinjam')->from("detail_transaksi")->count_all_results();
        $data['kembali'] = $this->db->where('status', 'Dikembalikan')->from("detail_transaksi")->count_all_results();
        $data['batal'] = $this->db->where('status', 'Dibatalkan')->from("detail_transaksi")->count_all_results();
        $this->load->view('templates/admin_header');
        $this->load->view('admin/index', $data);
        $this->load->view('templates/admin_footer');
        // $this->load->view('templates/footer');
    }
    public function penulis()
    {
        $data['judul'] = 'Data Penulis';
        $data['penulis'] = $this->Perpus_model->getAllPerpus();
        if ($this->input->post('keyword')) {
            $data['penulis'] = $this->Perpus_model->cariDataPenulis();
        }
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/index', $data);
        $this->load->view('templates/admin_footer');
    }
    public function tambah()
    {
        $data['judul'] = 'Form Tambah Data Penulis';
        $this->form_validation->set_rules('nm_penulis', 'Nama', 'required');
        $this->form_validation->set_rules('almt_penulis', 'Alamat', 'required');
        $this->form_validation->set_rules('telp_penulis', 'Nomor Telepon', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/tambah');
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->tambahDataPenulis();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('admin/penulis');
        }
    }
    public function hapus($id)
    {
        $this->Perpus_model->hapusDataPenulis($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('admin/penulis');
    }
    public function detail($id)
    {
        $data['judul'] = 'Detail Data Penulis';
        $data['penulis'] = $this->Perpus_model->getPenulisById($id);
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/detail', $data);
        $this->load->view('templates/admin_footer');
    }

    public function ubah($id)
    {
        $data['judul'] = 'Form Ubah Data Penulis';
        $data['penulis'] = $this->Perpus_model->getPenulisById($id);
        $this->form_validation->set_rules('kd_penulis', 'Kode Penulis', 'required|numeric');
        $this->form_validation->set_rules('nm_penulis', 'Nama', 'required');
        $this->form_validation->set_rules('almt_penulis', 'Alamat', 'required');
        $this->form_validation->set_rules('telp_penulis', 'Nomor Telepon', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/ubah', $data);
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->ubahDataPenulis();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('admin/penulis');
        }
    }
    //------------------------------CONTROLLER PENERBIT--------------------------------------------
    public function penerbit()
    {
        $data['judul'] = 'Data Penerbit';
        $data['penerbit'] = $this->Perpus_model->getAllPenerbit();
        if ($this->input->post('keyword')) {
            $data['penerbit'] = $this->Perpus_model->cariDataPenerbit();
        }
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/penerbit', $data);
        $this->load->view('templates/admin_footer');
    }
    public function detailPenerbit($id)
    {
        $data['judul'] = 'Detail Data penerbit';
        $data['penerbit'] = $this->Perpus_model->getpenerbitById($id);
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/detailPenerbit', $data);
        $this->load->view('templates/admin_footer');
    }
    public function tambahPenerbit()
    {
        $data['judul'] = 'Form Tambah Data Penerbit';
        $this->form_validation->set_rules('nm_penerbit', 'Nama', 'required');
        $this->form_validation->set_rules('almt_penerbit', 'Alamat', 'required');
        $this->form_validation->set_rules('telp_penerbit', 'Nomor Telepon', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/tambahPenerbit');
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->tambahDataPenerbit();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('admin/penerbit');
        }
    }
    public function hapusPenerbit($id)
    {
        $this->Perpus_model->hapusDataPenerbit($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('admin/penerbit');
    }
    public function ubahPenerbit($id)
    {
        $data['judul'] = 'Form Ubah Data Penerbit';
        $data['penerbit'] = $this->Perpus_model->getPenerbitById($id);
        $this->form_validation->set_rules('nm_penerbit', 'Nama', 'required');
        $this->form_validation->set_rules('almt_penerbit', 'Alamat', 'required');
        $this->form_validation->set_rules('telp_penerbit', 'Nomor Telepon', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/ubahPenerbit', $data);
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->ubahDataPenerbit();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('admin/penerbit');
        }
    }
    //------------------------------CONTROLLER KATEGORI------------------------------------------
    public function kategori()
    {
        $data['judul'] = 'Data kategori';
        $data['kategori'] = $this->Perpus_model->getAllkategori();
        if ($this->input->post('keyword')) {
            $data['kategori'] = $this->Perpus_model->cariDatakategori();
        }
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/kategori', $data);
        $this->load->view('templates/admin_footer');
    }
    public function detailkategori($id)
    {
        $data['judul'] = 'Detail Data kategori';
        $data['kategori'] = $this->Perpus_model->getkategoriById($id);
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/detailkategori', $data);
        $this->load->view('templates/admin_footer');
    }
    public function tambahkategori()
    {
        $data['judul'] = 'Form Tambah Data kategori';
        $this->form_validation->set_rules('kd_kategori', 'Kode Kategori', 'required');
        $this->form_validation->set_rules('nm_kategori', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/tambahkategori');
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->tambahDatakategori();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('admin/kategori');
        }
    }
    public function hapuskategori($id)
    {
        $this->Perpus_model->hapusDatakategori($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('admin/kategori');
    }
    public function ubahkategori($id)
    {
        $data['judul'] = 'Form Ubah Data kategori';
        $data['kategori'] = $this->Perpus_model->getkategoriById($id);
        $this->form_validation->set_rules('kd_kategori', 'Kode Kategori', 'required');
        $this->form_validation->set_rules('nm_kategori', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/ubahkategori', $data);
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->ubahDatakategori();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('admin/kategori');
        }
    }

    //------------------------------CONTROLLER RAK--------------------------------------------
    public function rak()
    {
        $data['judul'] = 'Data rak';
        $data['rak'] = $this->Perpus_model->getAllrak();
        if ($this->input->post('keyword')) {
            $data['rak'] = $this->Perpus_model->cariDatarak();
        }
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/rak', $data);
        $this->load->view('templates/admin_footer');
    }
    public function detailrak($id)
    {
        $data['judul'] = 'Detail Data rak';
        $data['rak'] = $this->Perpus_model->getrakById($id);
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/detailrak', $data);
        $this->load->view('templates/admin_footer');
    }
    public function tambahrak()
    {
        $data['judul'] = 'Form Tambah Data rak';
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $this->form_validation->set_rules('kd_rak', 'Kode rak', 'required');
        $this->form_validation->set_rules('nm_rak', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/tambahrak');
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->tambahDatarak();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('admin/rak');
        }
    }
    public function hapusrak($id)
    {
        $this->Perpus_model->hapusDatarak($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('admin/rak');
    }
    public function ubahrak($id)
    {
        $data['judul'] = 'Form Ubah Data rak';
        $data['rak'] = $this->Perpus_model->getrakById($id);
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $this->form_validation->set_rules('kd_rak', 'Kode rak', 'required');
        $this->form_validation->set_rules('nm_rak', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/ubahrak', $data);
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->ubahDatarak();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('admin/rak');
        }
    }
    //------------------------------CONTROLLER BUKU---------------------------------------------

    public function buku()
    {
        $data['judul'] = 'Data buku';
        $data['buku'] = $this->Perpus_model->getAlltampilbuku();
        if ($this->input->post('keyword')) {
            $data['buku'] = $this->Perpus_model->cariDatabuku();
        }
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/buku', $data);
        $this->load->view('templates/admin_footer');
    }
    public function detailbuku($id)
    {
        $data['judul'] = 'Detail Data buku';
        $data['buku'] = $this->Perpus_model->getbukuById($id);
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/detailbuku', $data);
        $this->load->view('templates/admin_footer');
    }
    public function tambahbuku()
    {
        $data['judul'] = 'Form Tambah Data buku';
        $data['buku'] = $this->Perpus_model->autoKodeBuku();
        $data['penerbit'] = $this->Perpus_model->getAllPenerbit();
        $data['penulis'] = $this->Perpus_model->getAllPerpus();
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $data['rak'] = $this->Perpus_model->getAllRak();
        $this->form_validation->set_rules('jdl_buku', 'Judul Buku', 'required');
        $this->form_validation->set_rules('isbn', 'ISBN', 'required');
        $this->form_validation->set_rules('kd_penulis', 'Nama Penulis', 'required');
        $this->form_validation->set_rules('kd_penerbit', 'Nama Penerbit', 'required');
        $this->form_validation->set_rules('kd_kategori', 'Kategori', 'required');
        $this->form_validation->set_rules('tgl_terbit', 'Tanggal Terbit', 'required');
        $this->form_validation->set_rules('jml_halaman', 'Jumlah Halaman', 'required|numeric');
        $this->form_validation->set_rules('kd_rak', 'Rak', 'required');
        $this->form_validation->set_rules('tgl_pengadaan', 'Tanggal Pengadaan', 'required');
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/tambahbuku', $data);
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->tambahDatabuku();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('admin/buku');
        }
    }
    public function hapusbuku($id)
    {
        $this->Perpus_model->hapusDatabuku($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('admin/buku');
    }
    public function ubahbuku($id)
    {
        $data['judul'] = 'Form Ubah Data buku';
        $data['buku'] = $this->Perpus_model->getbukuById($id);
        $data['penerbit'] = $this->Perpus_model->getAllPenerbit();
        $data['penulis'] = $this->Perpus_model->getAllPerpus();
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $data['rak'] = $this->Perpus_model->getAllRak();
        $this->form_validation->set_rules('jdl_buku', 'Judul Buku', 'required');
        $this->form_validation->set_rules('isbn', 'ISBN', 'required');
        $this->form_validation->set_rules('kd_penulis', 'Nama Penulis', 'required');
        $this->form_validation->set_rules('kd_penerbit', 'Nama Penerbit', 'required');
        $this->form_validation->set_rules('kd_kategori', 'Kategori', 'required');
        $this->form_validation->set_rules('tgl_terbit', 'Tanggal Terbit', 'required');
        $this->form_validation->set_rules('jml_halaman', 'Jumlah Halaman', 'required|numeric');
        $this->form_validation->set_rules('kd_rak', 'Rak', 'required');
        $this->form_validation->set_rules('tgl_pengadaan', 'Tanggal Pengadaan', 'required');
        $this->form_validation->set_rules('stok', 'Stok', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/ubahbuku', $data);
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->ubahDatabuku();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('admin/buku');
        }
    }
    //------------------------------CONTROLLER Anggota---------------------------------------------
    public function anggota()
    {
        $data['judul'] = 'Data anggota';
        $data['anggota'] = $this->Perpus_model->getallanggota();
        if ($this->input->post('keyword')) {
            $data['anggota'] = $this->Perpus_model->cariDataanggota();
        }
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/anggota', $data);
        $this->load->view('templates/admin_footer');
    }
    public function detailanggota($id)
    {
        $data['judul'] = 'Detail Data anggota';
        $data['anggota'] = $this->Perpus_model->getanggotaById($id);
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/detailanggota', $data);
        $this->load->view('templates/admin_footer');
    }
    public function tambahanggota()
    {
        $data['judul'] = 'Form Tambah Data anggota';
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('almt', 'Alamat', 'required');
        $this->form_validation->set_rules('telp', 'Nomor Telepon', 'required|numeric');
        $data['jk'] = ['Laki-laki', 'Perempuan'];
        $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[anggota.username_anggota]', [
            'is_unique' => 'This username has already registered!'
        ]);
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('password1', 'Password', 'required|trim|matches[password2]', [
            'matches' => 'Password dont match!'
        ]);
        $this->form_validation->set_rules('password2', 'Repeat Password', 'required|trim|matches[password1]');
        $this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
        $this->form_validation->set_rules('tl', 'Tempat Lahir', 'required');
        $this->form_validation->set_rules('tgl_lahir', 'Tanggal Lahir', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/tambahanggota');
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->tambahDataanggota();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('admin/anggota');
        }
    }
    public function hapusanggota($id)
    {
        $this->Perpus_model->hapusDataanggota($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('admin/anggota');
    }
    public function ubahanggota($id)
    {
        $data['jk'] = ['Laki-laki', 'Perempuan'];
        $data['judul'] = 'Form Ubah Data anggota';
        $data['anggota'] = $this->Perpus_model->getanggotaById($id);
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
        $this->form_validation->set_rules('almt', 'Alamat', 'required');
        $this->form_validation->set_rules('telp', 'Telepon', 'required|numeric');
        $this->form_validation->set_rules('tl', 'Tempat Lahir', 'required');
        $this->form_validation->set_rules('tgl_lahir', 'Tanggal Lahir', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/ubahanggota', $data);
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->ubahDataanggota();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('admin/anggota');
        }
    }
    //------------------------------CONTROLLER Pegawai---------------------------------------------
    public function pegawai()
    {
        $data['judul'] = 'Data pegawai';
        $data['pegawai'] = $this->Perpus_model->getallpegawai();
        if ($this->input->post('keyword')) {
            $data['pegawai'] = $this->Perpus_model->cariDatapegawai();
        }
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/pegawai', $data);
        $this->load->view('templates/admin_footer');
    }
    public function detailpegawai($id)
    {
        $data['judul'] = 'Detail Data pegawai';
        $data['pegawai'] = $this->Perpus_model->getpegawaiById($id);
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/detailpegawai', $data);
        $this->load->view('templates/admin_footer');
    }
    public function tambahpegawai()
    {
        $data['judul'] = 'Form Tambah Data pegawai';
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('almt', 'Alamat', 'required');
        $this->form_validation->set_rules('telp', 'Nomor Telepon', 'required|numeric');
        $data['jk'] = ['Laki-laki', 'Perempuan'];
        $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[pegawai.username_pegawai]', [
            'is_unique' => 'This username has already registered!'
        ]);
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('password1', 'Password', 'required|trim|matches[password2]', [
            'matches' => 'Password dont match!'
        ]);
        $this->form_validation->set_rules('password2', 'Repeat Password', 'required|trim|matches[password1]');
        $this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
        $this->form_validation->set_rules('tl', 'Tempat Lahir', 'required');
        $this->form_validation->set_rules('tgl_lahir', 'Tanggal Lahir', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/tambahpegawai');
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->tambahDatapegawai();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('admin/pegawai');
        }
    }
    public function hapuspegawai($id)
    {
        $this->Perpus_model->hapusDatapegawai($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('admin/pegawai');
    }
    public function ubahpegawai($id)
    {
        $data['jk'] = ['Laki-laki', 'Perempuan'];
        $data['judul'] = 'Form Ubah Data pegawai';
        $data['pegawai'] = $this->Perpus_model->getpegawaiById($id);
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
        $this->form_validation->set_rules('almt', 'Alamat', 'required');
        $this->form_validation->set_rules('telp', 'Telepon', 'required|numeric');
        $this->form_validation->set_rules('tl', 'Tempat Lahir', 'required');
        $this->form_validation->set_rules('tgl_lahir', 'Tanggal Lahir', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/admin_header', $data);
            $this->load->view('perpus/ubahpegawai', $data);
            $this->load->view('templates/admin_footer');
        } else {
            $this->Perpus_model->ubahDatapegawai();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('admin');
        }
    }


    public function detailtransaksi()
    {
        $data['detail'] = $this->Perpus_model->getalldetailtransaksi();
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/detailtransaksi', $data);
        $this->load->view('templates/admin_footer');
    }
    public function mastertransaksi()
    {
        $data['detail'] = $this->Perpus_model->getalldetailtransaksi();
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/mastertransaksi', $data);
        $this->load->view('templates/admin_footer');
    }
    public function peminjaman()
    {
        $data['detail'] = $this->Perpus_model->getalldetailtransaksi();
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/peminjaman', $data);
        $this->load->view('templates/admin_footer');
    }
    public function setujui()
    {
        //$cart_info = $_POST['cart'];
        $data = [
            "status" => "Dipinjam"
        ];
        $this->db->where('kode_transaksi', $this->input->post('kode_transaksi'));
        $this->db->update('detail_transaksi', $data);
        $master = [

            "tanggal_transaksi" => date('Y-m-d'),
            "kode_pegawai" => $this->session->userdata('id')
        ];
        $this->db->where('kode_transaksi', $this->input->post('kode_transaksi'));
        $this->db->update('master_transaksi', $master);

        $data['detail'] = $this->Perpus_model->getalldetailtransaksi();
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/peminjaman', $data);
        $this->load->view('templates/admin_footer');
    }
    public function batal()
    {
        //$cart_info = $_POST['cart'];
        $data = [
            "status" => "Dibatalkan"
        ];
        $this->db->where('kode_transaksi', $this->input->post('kode_transaksi'));
        $this->db->update('detail_transaksi', $data);
        $master = [

            "tanggal_transaksi" => date('Y-m-d'),
            "kode_pegawai" => $this->session->userdata('id')
        ];
        $this->db->where('kode_transaksi', $this->input->post('kode_transaksi'));
        $this->db->update('master_transaksi', $master);

        $data['detail'] = $this->Perpus_model->getalldetailtransaksi();
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/peminjaman', $data);
        $this->load->view('templates/admin_footer');
    }
    public function kembali()
    {
        //$cart_info = $_POST['cart'];
        $data = [
            "status" => "Dikembalikan"
        ];
        $this->db->where('kode_transaksi', $this->input->post('kode_transaksi'));
        $this->db->update('detail_transaksi', $data);
        $master = [
            "tanggal_transaksi" => date('Y-m-d'),
            "kode_pegawai" => $this->session->userdata('id')
        ];
        $this->db->where('kode_transaksi', $this->input->post('kode_transaksi'));
        $this->db->update('master_transaksi', $master);

        $data['detail'] = $this->Perpus_model->getalldetailtransaksi();
        $this->load->view('templates/admin_header', $data);
        $this->load->view('perpus/peminjaman', $data);
        $this->load->view('templates/admin_footer');
    }
}
