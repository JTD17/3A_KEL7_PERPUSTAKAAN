<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }
    public function index()
    {
        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');
        if ($this->form_validation->run() == false) {
            $data['title'] = 'Login Page';
            $this->load->view('templates/auth_header', $data);
            $this->load->view('auth/login');
            $this->load->view('templates/auth_footer');
        } else {
            $this->_login();
        }
    }

    private function _login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');

        $user = $this->db->get_where('anggota', ['username_anggota' => $username])->row_array();
        $admin = $this->db->get_where('pegawai', ['username_pegawai' => $username])->row_array();
        if ($user) {
            //cek pw
            if (password_verify($password, $user['password_anggota'])) {
                $data = [
                    'username' => $user['username_anggota'],
                    'id' => $user['kode_anggota'],
                    'anggota' => 'ok',
                    'admin' => '',
                    'nama' => $user['nama_anggota']
                ];
                $this->session->set_userdata($data);
                redirect('perpustakaan');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
        Wrong password!
      </div>');
                redirect('auth');
            }
        } else {
            if ($admin) {
                //cek pw
                if (password_verify($password, $admin['password_pegawai'])) {
                    $data = [
                        'username' => $admin['username_pegawai'],
                        'id' => $admin['kode_pegawai'],
                        'anggota' => '',
                        'admin' => 'ok',
                        'nama' => $user['nama_anggota']
                    ];
                    $this->session->set_userdata($data);
                    redirect('admin');
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
            Wrong password!
          </div>');
                    redirect('auth');
                }
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
                Email not registered!
              </div>');
            }
        }
    }


    public function registration()
    {
        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('username', 'Username', 'required|trim|is_unique[anggota.username_anggota]', [
            'is_unique' => 'This username has already registered!'
        ]);
        $this->form_validation->set_rules('password1', 'Password', 'required|trim|matches[password2]', [
            'matches' => 'Password dont match!'
        ]);
        $this->form_validation->set_rules('password2', 'Repeat Password', 'required|trim|matches[password1]');
        if ($this->form_validation->run() == false) {
            $data['title'] = 'Pendaftaran Anggota';
            $this->load->view('templates/auth_header', $data);
            $this->load->view('auth/registration');
            $this->load->view('templates/auth_footer');
        } else {
            $data = [
                'nama_anggota' => htmlspecialchars($this->input->post('name', true)),
                'username_anggota' => htmlspecialchars($this->input->post('username', true)),
                'password_anggota' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
                'tanggal_pendaftaran' => date('Y-m-d')

            ];
            $this->db->insert('anggota', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Congratulation your account has been created. Please Login!
          </div>');
            redirect('auth');
        }
    }
    public function logout()
    {
        $this->cart->destroy();
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('id');
        $this->session->unset_userdata('anggota');
        $this->session->unset_userdata('admin');
        $this->session->unset_userdata('nama');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
        You have been logged out!
      </div>');
        redirect('auth');
    }
}
