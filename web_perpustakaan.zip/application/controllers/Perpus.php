<?php

class Perpus extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Perpus_model');
        $this->load->library('cart');

        $this->load->library('form_validation');
    }
    //------------------------------CONTROLLER PENULIS----------------------------------------------
    public function index()
    {
        $data['judul'] = 'Data Penulis';
        $data['penulis'] = $this->Perpus_model->getAllPerpus();
        if ($this->input->post('keyword')) {
            $data['penulis'] = $this->Perpus_model->cariDataPenulis();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('perpus/index', $data);
        $this->load->view('templates/footer');
    }
    public function tambah()
    {
        $data['judul'] = 'Form Tambah Data Penulis';
        $this->form_validation->set_rules('nm_penulis', 'Nama', 'required');
        $this->form_validation->set_rules('almt_penulis', 'Alamat', 'required');
        $this->form_validation->set_rules('telp_penulis', 'Nomor Telepon', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('perpus/tambah');
            $this->load->view('templates/footer');
        } else {
            $this->Perpus_model->tambahDataPenulis();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('perpus');
        }
    }
    public function hapus($id)
    {
        $this->Perpus_model->hapusDataPenulis($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('perpus');
    }
    public function detail($id)
    {
        $data['judul'] = 'Detail Data Penulis';
        $data['penulis'] = $this->Perpus_model->getPenulisById($id);
        $this->load->view('templates/header', $data);
        $this->load->view('perpus/detail', $data);
        $this->load->view('templates/footer');
    }

    public function ubah($id)
    {
        $data['judul'] = 'Form Ubah Data Penulis';
        $data['penulis'] = $this->Perpus_model->getPenulisById($id);
        $this->form_validation->set_rules('kd_penulis', 'Kode Penulis', 'required|numeric');
        $this->form_validation->set_rules('nm_penulis', 'Nama', 'required');
        $this->form_validation->set_rules('almt_penulis', 'Alamat', 'required');
        $this->form_validation->set_rules('telp_penulis', 'Nomor Telepon', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('perpus/ubah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Perpus_model->ubahDataPenulis();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('perpus');
        }
    }
    //------------------------------CONTROLLER PENERBIT--------------------------------------------
    public function penerbit()
    {
        $data['judul'] = 'Data Penerbit';
        $data['penerbit'] = $this->Perpus_model->getAllPenerbit();
        if ($this->input->post('keyword')) {
            $data['penerbit'] = $this->Perpus_model->cariDataPenerbit();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('perpus/penerbit', $data);
        $this->load->view('templates/footer');
    }
    public function detailPenerbit($id)
    {
        $data['judul'] = 'Detail Data penerbit';
        $data['penerbit'] = $this->Perpus_model->getpenerbitById($id);
        $this->load->view('templates/header', $data);
        $this->load->view('perpus/detailPenerbit', $data);
        $this->load->view('templates/footer');
    }
    public function tambahPenerbit()
    {
        $data['judul'] = 'Form Tambah Data Penerbit';
        $this->form_validation->set_rules('nm_penerbit', 'Nama', 'required');
        $this->form_validation->set_rules('almt_penerbit', 'Alamat', 'required');
        $this->form_validation->set_rules('telp_penerbit', 'Nomor Telepon', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('perpus/tambahPenerbit');
            $this->load->view('templates/footer');
        } else {
            $this->Perpus_model->tambahDataPenerbit();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('perpus/penerbit');
        }
    }
    public function hapusPenerbit($id)
    {
        $this->Perpus_model->hapusDataPenerbit($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('perpus/penerbit');
    }
    public function ubahPenerbit($id)
    {
        $data['judul'] = 'Form Ubah Data Penerbit';
        $data['penerbit'] = $this->Perpus_model->getPenerbitById($id);
        $this->form_validation->set_rules('nm_penerbit', 'Nama', 'required');
        $this->form_validation->set_rules('almt_penerbit', 'Alamat', 'required');
        $this->form_validation->set_rules('telp_penerbit', 'Nomor Telepon', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('perpus/ubahPenerbit', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Perpus_model->ubahDataPenerbit();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('perpus/penerbit');
        }
    }
    //------------------------------CONTROLLER KATEGORI------------------------------------------
    public function kategori()
    {
        $data['judul'] = 'Data kategori';
        $data['kategori'] = $this->Perpus_model->getAllkategori();
        if ($this->input->post('keyword')) {
            $data['kategori'] = $this->Perpus_model->cariDatakategori();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('perpus/kategori', $data);
        $this->load->view('templates/footer');
    }
    public function detailkategori($id)
    {
        $data['judul'] = 'Detail Data kategori';
        $data['kategori'] = $this->Perpus_model->getkategoriById($id);
        $this->load->view('templates/header', $data);
        $this->load->view('perpus/detailkategori', $data);
        $this->load->view('templates/footer');
    }
    public function tambahkategori()
    {
        $data['judul'] = 'Form Tambah Data kategori';
        $this->form_validation->set_rules('kd_kategori', 'Kode Kategori', 'required');
        $this->form_validation->set_rules('nm_kategori', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('perpus/tambahkategori');
            $this->load->view('templates/footer');
        } else {
            $this->Perpus_model->tambahDatakategori();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('perpus/kategori');
        }
    }
    public function hapuskategori($id)
    {
        $this->Perpus_model->hapusDatakategori($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('perpus/kategori');
    }
    public function ubahkategori($id)
    {
        $data['judul'] = 'Form Ubah Data kategori';
        $data['kategori'] = $this->Perpus_model->getkategoriById($id);
        $this->form_validation->set_rules('kd_kategori', 'Kode Kategori', 'required');
        $this->form_validation->set_rules('nm_kategori', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('perpus/ubahkategori', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Perpus_model->ubahDatakategori();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('perpus/kategori');
        }
    }

    //------------------------------CONTROLLER RAK--------------------------------------------
    public function rak()
    {
        $data['judul'] = 'Data rak';
        $data['rak'] = $this->Perpus_model->getAllrak();
        if ($this->input->post('keyword')) {
            $data['rak'] = $this->Perpus_model->cariDatarak();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('perpus/rak', $data);
        $this->load->view('templates/footer');
    }
    public function detailrak($id)
    {
        $data['judul'] = 'Detail Data rak';
        $data['rak'] = $this->Perpus_model->getrakById($id);
        $this->load->view('templates/header', $data);
        $this->load->view('perpus/detailrak', $data);
        $this->load->view('templates/footer');
    }
    public function tambahrak()
    {
        $data['judul'] = 'Form Tambah Data rak';
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $this->form_validation->set_rules('kd_rak', 'Kode rak', 'required');
        $this->form_validation->set_rules('nm_rak', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('perpus/tambahrak');
            $this->load->view('templates/footer');
        } else {
            $this->Perpus_model->tambahDatarak();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('perpus/rak');
        }
    }
    public function hapusrak($id)
    {
        $this->Perpus_model->hapusDatarak($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('perpus/rak');
    }
    public function ubahrak($id)
    {
        $data['judul'] = 'Form Ubah Data rak';
        $data['rak'] = $this->Perpus_model->getrakById($id);
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $this->form_validation->set_rules('kd_rak', 'Kode rak', 'required');
        $this->form_validation->set_rules('nm_rak', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('perpus/ubahrak', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Perpus_model->ubahDatarak();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('perpus/rak');
        }
    }
    //------------------------------CONTROLLER BUKU---------------------------------------------

    public function buku()
    {
        $data['judul'] = 'Data buku';
        $data['buku'] = $this->Perpus_model->getAllbuku();
        if ($this->input->post('keyword')) {
            $data['buku'] = $this->Perpus_model->cariDatabuku();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('perpus/buku', $data);
        $this->load->view('templates/footer');
    }
    public function detailbuku($id)
    {
        $data['judul'] = 'Detail Data buku';
        $data['buku'] = $this->Perpus_model->getbukuById($id);
        $this->load->view('templates/header', $data);
        $this->load->view('perpus/detailbuku', $data);
        $this->load->view('templates/footer');
    }
    public function tambahbuku()
    {
        $data['judul'] = 'Form Tambah Data buku';
        $data['buku'] = $this->Perpus_model->autoKodeBuku();
        $data['penerbit'] = $this->Perpus_model->getAllPenerbit();
        $data['penulis'] = $this->Perpus_model->getAllPerpus();
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $data['rak'] = $this->Perpus_model->getAllRak();
        $this->form_validation->set_rules('jdl_buku', 'Judul Buku', 'required');
        $this->form_validation->set_rules('isbn', 'ISBN', 'required');
        $this->form_validation->set_rules('kd_penulis', 'Nama Penulis', 'required');
        $this->form_validation->set_rules('kd_penerbit', 'Nama Penerbit', 'required');
        $this->form_validation->set_rules('kd_kategori', 'Kategori', 'required');
        $this->form_validation->set_rules('tgl_terbit', 'Tanggal Terbit', 'required');
        $this->form_validation->set_rules('jml_halaman', 'Jumlah Halaman', 'required|numeric');
        $this->form_validation->set_rules('kd_rak', 'Rak', 'required');
        $this->form_validation->set_rules('tgl_pengadaan', 'Tanggal Pengadaan', 'required');
        $this->form_validation->set_rules('stok', 'Stok', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('perpus/tambahbuku', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Perpus_model->tambahDatabuku();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('perpus/buku');
        }
    }
    public function hapusbuku($id)
    {
        $this->Perpus_model->hapusDatabuku($id);
        $this->session->set_flashdata('flash', 'dihapus');
        redirect('perpus/buku');
    }
    public function ubahbuku($id)
    {
        $data['judul'] = 'Form Ubah Data buku';
        $data['buku'] = $this->Perpus_model->getbukuById($id);
        $data['penerbit'] = $this->Perpus_model->getAllPenerbit();
        $data['penulis'] = $this->Perpus_model->getAllPerpus();
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $data['rak'] = $this->Perpus_model->getAllRak();
        $this->form_validation->set_rules('jdl_buku', 'Judul Buku', 'required');
        $this->form_validation->set_rules('isbn', 'ISBN', 'required|numeric');
        $this->form_validation->set_rules('kd_penulis', 'Nama Penulis', 'required');
        $this->form_validation->set_rules('kd_penerbit', 'Nama Penerbit', 'required');
        $this->form_validation->set_rules('kd_kategori', 'Kategori', 'required');
        $this->form_validation->set_rules('tgl_terbit', 'Tanggal Terbit', 'required');
        $this->form_validation->set_rules('jml_halaman', 'Jumlah Halaman', 'required|numeric');
        $this->form_validation->set_rules('kd_rak', 'Rak', 'required');
        $this->form_validation->set_rules('tgl_pengadaan', 'Tanggal Pengadaan', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('perpus/ubahbuku', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Perpus_model->ubahDatabuku();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('perpus/buku');
        }
    }
}
