<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Perpustakaan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('cart');
        $this->load->model('Perpus_model');
        $this->load->library('form_validation');
    }
    public function index()
    {
        $data['n_home'] = 'active';
        $data['n_buku'] = ' ';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = ' ';
        $data['n_tentang'] = ' ';
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $data['penulis'] = $this->Perpus_model->getAllPerpus();
        $data['penulis_limit'] = $this->Perpus_model->getAllPenulisDesc();
        $data['buku_laris'] = $this->Perpus_model->getAllBukuLaris();
        $data['buku_laris2'] = $this->Perpus_model->getAllBukuLaris2();
        $data['penulis_limit2'] = $this->Perpus_model->getAllPenulisDesc2();
        $data['rak'] = $this->Perpus_model->getAllRak();
        $data['buku'] = $this->Perpus_model->getAlltampilbukustok();
        if ($this->input->post('keyword')) {
            $data['buku'] = $this->Perpus_model->cariDatabuku();
        }
        $data['buku_limit'] = $this->Perpus_model->getAllBukuLimit();
        $data['buku_limit3'] = $this->Perpus_model->getAllBukuLimit3();
        $this->form_validation->set_rules('kode_buku', 'Kode rak', 'required');
        $this->form_validation->set_rules('judul_buku', 'Kode rak', 'required');
        $this->form_validation->set_rules('max_stok', 'Kode rak', 'required');
        $this->form_validation->set_rules('jumlah_buku', 'Nama', 'required');
        $this->form_validation->set_rules('tanggal_pinjam', 'Nama', 'required');
        $this->form_validation->set_rules('tanggal_kembali', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/perpustakaan_header', $data);
            $this->load->view('perpustakaan/index', $data);
            $this->load->view('templates/perpustakaan_footer');
        } else {
            if (empty($this->session->userdata('anggota'))) {
                redirect('auth');
            } else {
                $this->Perpus_model->add_cart();
                redirect('perpustakaan/keranjang');
            }
        }
    }
    public function buku()
    {
        $data['n_home'] = ' ';
        $data['n_buku'] = 'active';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = ' ';
        $data['n_tentang'] = ' ';
        $this->form_validation->set_rules('kode_buku', 'Kode rak', 'required');
        $this->form_validation->set_rules('judul_buku', 'Kode rak', 'required');
        $this->form_validation->set_rules('max_stok', 'Kode rak', 'required');
        $this->form_validation->set_rules('jumlah_buku', 'Nama', 'required');
        $this->form_validation->set_rules('tanggal_pinjam', 'Nama', 'required');
        $this->form_validation->set_rules('tanggal_kembali', 'Nama', 'required');
        $data['buku_stok'] = $this->Perpus_model->getAlltampilbukustok();
        if ($this->input->post('keyword')) {
            $data['buku_stok'] = $this->Perpus_model->caritampilbukustok();
        }
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/perpustakaan_header', $data);
            $this->load->view('perpustakaan/buku', $data);
            $this->load->view('templates/perpustakaan_footer');
        } else {
            if (empty($this->session->userdata('anggota'))) {
                redirect('auth');
            } else {
                $this->Perpus_model->add_cart();
                redirect('perpustakaan/keranjang');
            }
        }
    }
    public function habis()
    {
        $data['n_home'] = '';
        $data['n_buku'] = 'active';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = ' ';
        $data['n_tentang'] = ' ';
        $data['buku_stok'] = $this->Perpus_model->getAlltampilbukuhabis();
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $this->load->view('templates/perpustakaan_header', $data);
        $this->load->view('perpustakaan/habis', $data);
        $this->load->view('templates/perpustakaan_footer');
    }
    public function penulis()
    {
        $data['n_home'] = '';
        $data['n_buku'] = '';
        $data['n_penulis'] = 'active';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = ' ';
        $data['n_tentang'] = ' ';
        $data['penulis'] = $this->Perpus_model->getAllPerpus();
        if ($this->input->post('keyword')) {
            $data['penulis'] = $this->Perpus_model->cariDataPenulis();
        }
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $this->load->view('templates/perpustakaan_header', $data);
        $this->load->view('perpustakaan/penulis', $data);
        $this->load->view('templates/perpustakaan_footer');
    }
    public function penerbit()
    {
        $data['n_home'] = '';
        $data['n_buku'] = '';
        $data['n_penulis'] = '';
        $data['n_penerbit'] = 'active';
        $data['n_rak'] = ' ';
        $data['n_tentang'] = ' ';

        $data['penerbit'] = $this->Perpus_model->getAllPenerbit();
        if ($this->input->post('keyword')) {
            $data['penerbit'] = $this->Perpus_model->cariDataPenerbit();
        }
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $this->load->view('templates/perpustakaan_header', $data);
        $this->load->view('perpustakaan/penerbit', $data);
        $this->load->view('templates/perpustakaan_footer');
    }
    public function kategori($id)
    {
        $data['n_home'] = '';
        $data['n_buku'] = 'active';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = ' ';
        $data['n_tentang'] = ' ';
        $data['kategori_cari'] = $this->Perpus_model->getAlltampilbukukategori($id);
        if ($this->input->post('keyword')) {
            $data['kategori_cari'] = $this->Perpus_model->caritampilbukukategori($id);
        }
        $data['id'] = $id;
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $this->form_validation->set_rules('kode_buku', 'Kode rak', 'required');
        $this->form_validation->set_rules('judul_buku', 'Kode rak', 'required');
        $this->form_validation->set_rules('max_stok', 'Kode rak', 'required');
        $this->form_validation->set_rules('jumlah_buku', 'Nama', 'required');
        $this->form_validation->set_rules('tanggal_pinjam', 'Nama', 'required');
        $this->form_validation->set_rules('tanggal_kembali', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/perpustakaan_header', $data);
            $this->load->view('perpustakaan/kategori', $data, $id);
            $this->load->view('templates/perpustakaan_footer');
        } else {
            if (empty($this->session->userdata('anggota'))) {
                redirect('auth');
            } else {
                $this->Perpus_model->add_cart();
                redirect('perpustakaan/keranjang');
            }
        }
    }
    public function tentang()
    {
        $data['n_home'] = '';
        $data['n_buku'] = '';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = ' ';
        $data['n_tentang'] = 'active';

        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $this->load->view('templates/perpustakaan_header', $data);
        $this->load->view('perpustakaan/tentang', $data);
        $this->load->view('templates/perpustakaan_footer');
    }
    public function rak()
    {
        $data['n_home'] = '';
        $data['n_buku'] = '';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = 'active';
        $data['n_tentang'] = '';

        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $data['rak'] = $this->Perpus_model->getAllRak();
        if ($this->input->post('keyword')) {
            $data['rak'] = $this->Perpus_model->cariDatarak();
        }
        $this->load->view('templates/perpustakaan_header', $data);
        $this->load->view('perpustakaan/rak', $data);
        $this->load->view('templates/perpustakaan_footer');
    }
    public function detail($id)
    {
        $data['n_home'] = '';
        $data['n_buku'] = 'active';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = '';
        $data['n_tentang'] = '';

        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $data['buku'] = $this->Perpus_model->getbukuById($id);
        $this->form_validation->set_rules('kode_buku', 'Kode rak', 'required');
        $this->form_validation->set_rules('judul_buku', 'Kode rak', 'required');
        $this->form_validation->set_rules('max_stok', 'Kode rak', 'required');
        $this->form_validation->set_rules('jumlah_buku', 'Nama', 'required');
        $this->form_validation->set_rules('tanggal_pinjam', 'Nama', 'required');
        $this->form_validation->set_rules('tanggal_kembali', 'Nama', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/perpustakaan_header2', $data);
            $this->load->view('perpustakaan/detail', $data);
            $this->load->view('templates/perpustakaan_footer');
        } else {
            if (empty($this->session->userdata('anggota'))) {
                redirect('auth');
            } else {
                $this->Perpus_model->add_cart();
                redirect('perpustakaan/keranjang');
            }
        }
    }
    public function keranjang()
    {
        if (empty($this->session->userdata('anggota'))) {
            redirect('auth');
        }
        $data['n_home'] = '';
        $data['n_buku'] = '';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = '';
        $data['n_tentang'] = '';

        $data['kategori'] = $this->Perpus_model->getAllKategori();

        $this->load->view('templates/perpustakaan_header2', $data);
        $this->load->view('perpustakaan/keranjang', $data);
        $this->load->view('templates/perpustakaan_footer');
    }
    public function anggota()
    {
        if (empty($this->session->userdata('anggota'))) {
            redirect('auth');
        }
        $data['n_home'] = '';
        $data['n_buku'] = '';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = '';
        $data['n_tentang'] = '';

        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $data['anggota'] = $this->Perpus_model->angota();
        $data['jk'] = ['Laki-laki', 'Perempuan'];
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('jk', 'Jenis Kelamin', 'required');
        $this->form_validation->set_rules('almt', 'Alamat', 'required');
        $this->form_validation->set_rules('telp', 'Telepon', 'required');
        $this->form_validation->set_rules('tl', 'Tempat Lahir', 'required');
        $this->form_validation->set_rules('tgl_lahir', 'Tanggal Lahir', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/perpustakaan_header2', $data);
            $this->load->view('perpustakaan/anggota', $data);
            $this->load->view('templates/perpustakaan_footer');
        } else {
            $this->Perpus_model->ubahAnggota();
            redirect('perpustakaan');
        }
    }
    public function peminjaman()
    {
        if (empty($this->session->userdata('anggota'))) {
            redirect('auth');
        }
        $data['n_home'] = '';
        $data['n_buku'] = '';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = '';
        $data['n_tentang'] = '';

        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $data['pinjam'] = $this->Perpus_model->detailPeminjaman();

        $this->load->view('templates/perpustakaan_header2', $data);
        $this->load->view('perpustakaan/peminjaman', $data);
        $this->load->view('templates/perpustakaan_footer');
    }

    function hapus_cart($rowid)
    {
        if (empty($this->session->userdata('anggota'))) {
            redirect('auth');
        }
        if ($rowid == "all") {
            $this->cart->destroy();
        } else {
            $data = array(
                'rowid' => $rowid,
                'qty' => 0
            );
            $this->cart->update($data);
        }
        redirect('perpustakaan/keranjang');
    }
    function ubah_cart()
    {
        if (empty($this->session->userdata('anggota'))) {
            redirect('auth');
        }
        $cart_info = $_POST['cart'];
        foreach ($cart_info as $id => $cart) {
            $rowid = $cart['rowid'];
            $price = $cart['price'];
            $qty = $cart['qty'];
            $data = array(
                'rowid' => $rowid,
                'price' => $price,
                'qty' => $qty
            );
            $this->cart->update($data);
        }
        redirect('perpustakaan/keranjang');
    }
    public function proses_order()
    {
        if (empty($this->session->userdata('anggota'))) {
            redirect('auth');
        }
        if ($cart = $this->cart->contents()) {
            foreach ($cart as $item) {
                $data_detail = array(
                    'kode_transaksi' => $this->session->userdata('id') . $item['id'] . $item['tanggal_pinjam'],
                    'kode_buku' => $item['id'],
                    'jumlah_buku' => $item['qty'],
                    'tanggal_pinjam' => $item['tanggal_pinjam'],
                    'tanggal_kembali' => $item['tanggal_kembali'],
                    'status' => 'Menunggu'
                );
                $proses = $this->Perpus_model->tambah_detail_order($data_detail);

                $data_master = array(
                    'kode_transaksi' => $this->session->userdata('id') . $item['id'] . $item['tanggal_pinjam'],
                    'tanggal_transaksi' => date('Y-m-d'),
                    'kode_anggota' => $this->session->userdata('id'),
                    'kode_pegawai' => '1'
                );
                $id_master = $this->Perpus_model->tambah_master_order($data_master);
            }
        }
        //-------------------------Hapus shopping cart--------------------------
        $this->cart->destroy();
        $data['n_home'] = '';
        $data['n_buku'] = '';
        $data['n_penulis'] = ' ';
        $data['n_penerbit'] = ' ';
        $data['n_rak'] = ' ';
        $data['n_tentang'] = 'active';
        $data['kategori'] = $this->Perpus_model->getAllKategori();
        $data['pinjam'] = $this->Perpus_model->detailPeminjaman();
        $this->load->view('templates/perpustakaan_header2', $data);
        $this->load->view('perpustakaan/peminjaman', $data);
        $this->load->view('templates/perpustakaan_footer');
    }
}
