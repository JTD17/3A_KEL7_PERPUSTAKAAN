<?php

class Perpus_model extends CI_model
{
    //------------------------------MODEL PENULIS---------------------------------------------
    public function getAllPerpus()
    {
        return $this->db->get('penulis')->result_array();
    }
    public function getAllPenulisDesc()
    {
        $this->db->order_by('kode_penulis', 'desc');
        return $this->db->get('penulis', 3, 0)->result_array();
    }
    public function getAllPenulisDesc2()
    {
        $this->db->order_by('kode_penulis', 'desc');
        return $this->db->get('penulis', 3, 3)->result_array();
    }
    public function tambahDataPenulis()
    {
        $data = [
            "nama_penulis" => $this->input->post('nm_penulis', true),
            "alamat_penulis" => $this->input->post('almt_penulis', true),
            "telp_penulis" => $this->input->post('telp_penulis', true)

        ];
        $this->db->insert('penulis', $data);
    }
    public function hapusDataPenulis($id)
    {
        //$this->db->where('kode_penulis',$id);
        $this->db->delete('penulis', ['kode_penulis' => $id]);
    }
    public function getPenulisById($id)
    {
        return $this->db->get_where('penulis', ['kode_penulis' => $id])->row_array();
    }

    public function ubahDataPenulis()
    {
        $data = [
            "kode_penulis" => $this->input->post('kd_penulis', true),
            "nama_penulis" => $this->input->post('nm_penulis', true),
            "alamat_penulis" => $this->input->post('almt_penulis', true),
            "telp_penulis" => $this->input->post('telp_penulis', true)

        ];
        $this->db->where('kode_penulis', $this->input->post('id'));
        $this->db->update('penulis', $data);
    }

    public function cariDataPenulis()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('nama_penulis', $keyword);
        return $this->db->get('penulis')->result_array();
    }

    //------------------------------MODEL PENERBIT---------------------------------------------


    public function getAllPenerbit()
    {
        return $this->db->get('penerbit')->result_array();
    }
    public function cariDataPenerbit()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('nama_penerbit', $keyword);
        return $this->db->get('penerbit')->result_array();
    }
    public function getPenerbitById($id)
    {
        return $this->db->get_where('penerbit', ['kode_penerbit' => $id])->row_array();
    }
    public function tambahDataPenerbit()
    {
        $data = [
            "kode_penerbit" => $this->input->post('kd_penerbit', true),
            "nama_penerbit" => $this->input->post('nm_penerbit', true),
            "alamat_penerbit" => $this->input->post('almt_penerbit', true),
            "telp_penerbit" => $this->input->post('telp_penerbit', true)

        ];
        $this->db->insert('penerbit', $data);
    }
    public function hapusDataPenerbit($id)
    {
        //$this->db->where('kode_penulis',$id);
        $this->db->delete('penerbit', ['kode_penerbit' => $id]);
    }
    public function ubahDatapenerbit()
    {
        $data = [
            "kode_penerbit" => $this->input->post('kd_penerbit', true),
            "nama_penerbit" => $this->input->post('nm_penerbit', true),
            "alamat_penerbit" => $this->input->post('almt_penerbit', true),
            "telp_penerbit" => $this->input->post('telp_penerbit', true)

        ];
        $this->db->where('kode_penerbit', $this->input->post('id'));
        $this->db->update('penerbit', $data);
    }
    //------------------------------MODEL BUKU---------------------------------------------

    public function getAllbuku()
    {
        return $this->db->get('buku')->result_array();
    }
    public function getAlltampilbuku()
    {
        return $this->db->get('tampil_buku')->result_array();
    }
    public function getAlltampilbukustok()
    {
        $this->db->where('stok !=', 0);
        return $this->db->get('tampil_buku')->result_array();
    }
    public function getAlltampilbukukategori($id)
    {
        $this->db->where('stok !=', 0);
        return $this->db->get_where('tampil_buku', ['nama_kategori' => $id])->result_array();
    }
    public function caritampilbukukategori($id)
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->where('stok !=', 0);
        $this->db->like('judul_buku', $keyword);
        return $this->db->get_where('tampil_buku', ['nama_kategori' => $id])->result_array();
    }

    public function caritampilbukustok()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->where('stok !=', 0);
        $this->db->like('judul_buku', $keyword);
        return $this->db->get('tampil_buku')->result_array();
    }
    public function getAlltampilbukuhabis()
    {
        $this->db->where('stok =', 0);
        return $this->db->get('tampil_buku')->result_array();
    }
    public function getAllBukuLimit()
    {
        return $this->db->get('ambil_no_buku', 3, 0)->result_array();
    }
    public function getAllBukuLimit3()
    {
        return $this->db->get('ambil_no_buku', 3, 3)->result_array();
    }
    public function cariDatabuku()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('judul_buku', $keyword);
        return $this->db->get('tampil_buku')->result_array();
    }
    public function getbukuById($id)
    {
        return $this->db->get_where('tampil_buku', ['kode_buku' => $id])->row_array();
    }
    public function tambahDatabuku()
    {
        $data = [
            "kode_buku" => $this->input->post('kd_buku', true),
            "judul_buku" => $this->input->post('jdl_buku', true),
            "isbn" => $this->input->post('isbn', true),
            "kode_penulis" => $this->input->post('kd_penulis', true),
            "kode_penerbit" => $this->input->post('kd_penerbit', true),
            "kode_kategori" => $this->input->post('kd_kategori', true),
            "tanggal_terbit" => $this->input->post('tgl_terbit', true),
            "jumlah_halaman" => $this->input->post('jml_halaman', true),
            "kode_rak" => $this->input->post('kd_rak', true),
            "tanggal_pengadaan" => $this->input->post('tgl_pengadaan', true),
            "stok" => $this->input->post('stok', true)

        ];
        $this->db->insert('buku', $data);
    }
    public function hapusDatabuku($id)
    {
        //$this->db->where('kode_penulis',$id);
        $this->db->delete('buku', ['kode_buku' => $id]);
    }
    public function ubahDatabuku()
    {
        $data = [
            "judul_buku" => $this->input->post('jdl_buku', true),
            "isbn" => $this->input->post('isbn', true),
            "kode_penulis" => $this->input->post('kd_penulis', true),
            "kode_penerbit" => $this->input->post('kd_penerbit', true),
            "kode_kategori" => $this->input->post('kd_kategori', true),
            "tanggal_terbit" => $this->input->post('tgl_terbit', true),
            "jumlah_halaman" => $this->input->post('jml_halaman', true),
            "kode_rak" => $this->input->post('kd_rak', true),
            "tanggal_pengadaan" => $this->input->post('tgl_pengadaan', true),
            "stok" => $this->input->post('stok', true)

        ];
        $this->db->where('kode_buku', $this->input->post('id'));
        $this->db->update('buku', $data);
    }
    public function autoKodeBuku()
    {
        return $this->db->get('ambil_no_buku')->row_array();
    }


    //------------------------------MODEL KATEGORI---------------------------------------------

    public function getAllKategori()
    {
        return $this->db->get('kategori')->result_array();
    }
    public function cariDatakategori()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('nama_kategori', $keyword);
        return $this->db->get('kategori')->result_array();
    }
    public function getkategoriById($id)
    {
        return $this->db->get_where('kategori', ['kode_kategori' => $id])->row_array();
    }
    public function tambahDatakategori()
    {
        $data = [
            "kode_kategori" => $this->input->post('kd_kategori', true),
            "nama_kategori" => $this->input->post('nm_kategori', true)

        ];
        $this->db->insert('kategori', $data);
    }
    public function hapusDatakategori($id)
    {
        //$this->db->where('kode_penulis',$id);
        $this->db->delete('kategori', ['kode_kategori' => $id]);
    }
    public function ubahDatakategori()
    {
        $data = [
            "kode_kategori" => $this->input->post('kd_kategori', true),
            "nama_kategori" => $this->input->post('nm_kategori', true)

        ];
        $this->db->where('kode_kategori', $this->input->post('id'));
        $this->db->update('kategori', $data);
    }
    //------------------------------MODEL RAK---------------------------------------------
    public function getAllRak()
    {
        return $this->db->get('tampil_rak')->result_array();
    }
    public function cariDatarak()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('nama_rak', $keyword);
        return $this->db->get('rak')->result_array();
    }
    public function getrakById($id)
    {
        return $this->db->get_where('tampil_rak', ['kode_rak' => $id])->row_array();
    }
    public function tambahDatarak()
    {
        $data = [
            "kode_rak" => $this->input->post('kd_rak', true),
            "nama_rak" => $this->input->post('nm_rak', true),
            "kode_kategori" => $this->input->post('kd_kategori', true)

        ];
        $this->db->insert('rak', $data);
    }
    public function hapusDatarak($id)
    {
        //$this->db->where('kode_penulis',$id);
        $this->db->delete('rak', ['kode_rak' => $id]);
    }
    public function ubahDatarak()
    {
        $data = [
            "kode_rak" => $this->input->post('kd_rak', true),
            "nama_rak" => $this->input->post('nm_rak', true),
            "kode_kategori" => $this->input->post('kd_kategori', true)

        ];
        $this->db->where('kode_rak', $this->input->post('id'));
        $this->db->update('rak', $data);
    }
    //------------------------------MODEL DETAIL TRANSAKSI---------------------------------------------
    public function getAllBukuLaris()
    {
        return $this->db->get('tampil_buku_laris', 3, 0)->result_array();
    }
    public function getAllBukuLaris2()
    {
        return $this->db->get('tampil_buku_laris', 3, 3)->result_array();
    }

    public function add_cart()
    {
        $data = array(
            'id'      => $this->input->post('kode_buku', true),
            'qty'     => $this->input->post('jumlah_buku', true),
            'price'   => 0,
            'name'    => $this->input->post('judul_buku', true),
            'stok'    => $this->input->post('max_stok', true),
            'tanggal_pinjam' => $this->input->post('tanggal_pinjam', true),
            'tanggal_kembali' => $this->input->post('tanggal_kembali', true)
        );
        $this->cart->insert($data);
    }
    public function tambah_detail_order($data)
    {
        $this->db->insert('detail_transaksi', $data);
    }
    public function tambah_master_order($data)
    {
        $this->db->insert('master_transaksi', $data);
    }
    public function detailPeminjaman()
    {
        $this->db->like('kode_anggota', $this->session->userdata('id'));
        return $this->db->get('detail_peminjaman')->result_array();
    }
    public function angota()
    {
        $this->db->like('kode_anggota', $this->session->userdata('id'));
        return $this->db->get('anggota')->row_array();
    }

    public function ubahAnggota()
    {
        $data = [
            "kode_anggota" => $this->input->post('kode_anggota', true),
            "username_anggota" => $this->input->post('username', true),
            "nama_anggota" => $this->input->post('nama', true),
            "jenis_kelamin" => $this->input->post('jk', true),
            "alamat_anggota" => $this->input->post('almt', true),
            "telp_anggota" => $this->input->post('telp', true),
            "tempat_lahir" => $this->input->post('tl', true),
            "tanggal_lahir" => $this->input->post('tgl_lahir', true)

        ];
        $anggota = [
            'username' => $this->input->post('username', true),
            'nama' => $this->input->post('nama', true)
        ];
        $this->session->set_userdata($anggota);
        $this->db->where('kode_anggota', $this->input->post('kode_anggota'));
        $this->db->update('anggota', $data);
    }
    //------------------------------MODEL DETAIL Anggota---------------------------------------------
    public function getallanggota()
    {
        return $this->db->get('anggota')->result_array();
    }
    public function caridataanggota()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('nama_anggota', $keyword);
        return $this->db->get('anggota')->result_array();
    }
    public function getanggotaById($id)
    {
        return $this->db->get_where('anggota', ['kode_anggota' => $id])->row_array();
    }
    public function tambahdataanggota()
    {
        $data = [
            "username_anggota" => $this->input->post('username', true),
            'password_anggota' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
            "nama_anggota" => $this->input->post('nama', true),
            "jenis_kelamin" => $this->input->post('jk', true),
            "alamat_anggota" => $this->input->post('almt', true),
            "telp_anggota" => $this->input->post('telp', true),
            "tempat_lahir" => $this->input->post('tl', true),
            "tanggal_lahir" => $this->input->post('tgl_lahir', true),
            "tanggal_pendaftaran" => date('Y-m-d')
        ];
        $this->db->insert('anggota', $data);
    }
    public function hapusdataanggota($id)
    {
        //$this->db->where('kode_penulis',$id);
        $this->db->delete('anggota', ['kode_anggota' => $id]);
    }
    public function ubahdataanggota()
    {
        $data = [
            "kode_anggota" => $this->input->post('kode_anggota', true),
            "username_anggota" => $this->input->post('username', true),
            "nama_anggota" => $this->input->post('nama', true),
            "jenis_kelamin" => $this->input->post('jk', true),
            "alamat_anggota" => $this->input->post('almt', true),
            "telp_anggota" => $this->input->post('telp', true),
            "tempat_lahir" => $this->input->post('tl', true),
            "tanggal_lahir" => $this->input->post('tgl_lahir', true)

        ];
        $this->db->where('kode_anggota', $this->input->post('kode_anggota'));
        $this->db->update('anggota', $data);
    }
    //------------------------------MODEL DETAIL Pegawai---------------------------------------------
    public function getallpegawai()
    {
        return $this->db->get('pegawai')->result_array();
    }
    public function caridatapegawai()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('nama_pegawai', $keyword);
        return $this->db->get('pegawai')->result_array();
    }
    public function getpegawaiById($id)
    {
        return $this->db->get_where('pegawai', ['kode_pegawai' => $id])->row_array();
    }
    public function tambahdatapegawai()
    {
        $data = [
            "username_pegawai" => $this->input->post('username', true),
            'password_pegawai' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
            "nama_pegawai" => $this->input->post('nama', true),
            "jenis_kelamin" => $this->input->post('jk', true),
            "alamat_pegawai" => $this->input->post('almt', true),
            "telp_pegawai" => $this->input->post('telp', true),
            "tempat_lahir" => $this->input->post('tl', true),
            "tanggal_lahir" => $this->input->post('tgl_lahir', true)
        ];
        $this->db->insert('pegawai', $data);
    }
    public function hapusdatapegawai($id)
    {
        //$this->db->where('kode_penulis',$id);
        $this->db->delete('pegawai', ['kode_pegawai' => $id]);
    }
    public function ubahdatapegawai()
    {
        $data = [
            "kode_pegawai" => $this->input->post('kode_pegawai', true),
            "username_pegawai" => $this->input->post('username', true),
            "nama_pegawai" => $this->input->post('nama', true),
            "jenis_kelamin" => $this->input->post('jk', true),
            "alamat_pegawai" => $this->input->post('almt', true),
            "telp_pegawai" => $this->input->post('telp', true),
            "tempat_lahir" => $this->input->post('tl', true),
            "tanggal_lahir" => $this->input->post('tgl_lahir', true)

        ];
        $anggota = [
            'username' => $this->input->post('username', true),
            'nama' => $this->input->post('nama', true)
        ];
        $this->session->set_userdata($anggota);
        $this->db->where('kode_pegawai', $this->input->post('kode_pegawai'));
        $this->db->update('pegawai', $data);
    }
    //------------------------------MODEL DETAIL Pegawai---------------------------------------------
    public function getalldetailtransaksi()
    {
        return $this->db->get('detail_peminjaman')->result_array();
    }
    public function getallmastertransaksi()
    {
        return $this->db->get('detail_peminjaman')->result_array();
    }


    public function selectRecordsAnggota()
    {
        return $this->db->count_all_results('anggota')->row_array;
    }
}
