<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Table Anggota</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Anggota</h6>
        </div>
        <div class="col-md-6 mt-3">
            <a href="<?= base_url(); ?>admin/tambahanggota" class="btn btn-primary">Tambah Data Anggota</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Kode Anggota</th>
                            <th>Username </th>
                            <th>Nama Anggota</th>
                            <th>Jenis Kelamin</th>
                            <th>Alamat</th>
                            <th>Telepon</th>
                            <th>Tempat Lahir</th>
                            <th>Tanggal Lahir</th>
                            <th>Tanggal Pendaftaran</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Kode Anggota</th>
                            <th>Username </th>
                            <th>Nama Anggota</th>
                            <th>Jenis Kelamin</th>
                            <th>Alamat</th>
                            <th>Telepon</th>
                            <th>Tempat Lahir</th>
                            <th>Tanggal Lahir</th>
                            <th>Tanggal Pendaftaran</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php foreach ($anggota as $angg) : ?>
                            <tr>
                                <td><?= $angg['kode_anggota']; ?></td>
                                <td><?= $angg['username_anggota']; ?></td>
                                <td><?= $angg['nama_anggota']; ?></td>
                                <td><?= $angg['jenis_kelamin']; ?></td>
                                <td><?= $angg['alamat_anggota']; ?></td>
                                <td><?= $angg['telp_anggota']; ?></td>
                                <td><?= $angg['tempat_lahir']; ?></td>
                                <td><?= $angg['tanggal_lahir']; ?></td>
                                <td><?= $angg['tanggal_pendaftaran']; ?></td>
                                <td><a href="<?= base_url(); ?>admin/hapusanggota/<?= $angg['kode_anggota']; ?>" class="badge badge-danger float-right" onclick="return confirm('yakin ?');">Hapus</a>
                                    <a href="<?= base_url(); ?>admin/ubahanggota/<?= $angg['kode_anggota']; ?>" class="badge badge-success float-right">Ubah</a>
                                    <a href="<?= base_url(); ?>admin/detailanggota/<?= $angg['kode_anggota']; ?>" class="badge badge-primary float-right">Detail</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->