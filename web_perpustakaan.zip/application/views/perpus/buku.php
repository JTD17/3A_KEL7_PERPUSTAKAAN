<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Table Buku</h1>
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data Buku</h6>
    </div>
    <div class="col-md-6 mt-3">
      <a href="<?= base_url(); ?>admin/tambahbuku" class="btn btn-primary">Tambah Data Buku</a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Kode Buku</th>
              <th>Judul Buku</th>
              <th>ISBN</th>
              <th>Penulis</th>
              <th>Penerbit</th>
              <th>Kategori</th>
              <th>Tanggal Terbit</th>
              <th>Jumlah Halaman</th>
              <th>Rak</th>
              <th>Tanggal Pengadaan</th>
              <th>Stok</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>Kode Buku</th>
              <th>Judul Buku</th>
              <th>ISBN</th>
              <th>Penulis</th>
              <th>Penerbit</th>
              <th>Kategori</th>
              <th>Tanggal Terbit</th>
              <th>Jumlah Halaman</th>
              <th>Rak</th>
              <th>Tanggal Pengadaan</th>
              <th>Stok</th>
              <th>Action</th>
            </tr>
          </tfoot>
          <tbody>
            <?php foreach ($buku as $bk) : ?>
              <tr>
                <td><?= $bk['kode_buku']; ?></td>
                <td><?= $bk['judul_buku']; ?></td>
                <td><?= $bk['isbn']; ?></td>
                <td><?= $bk['nama_penulis']; ?></td>
                <td><?= $bk['nama_penerbit']; ?></td>
                <td><?= $bk['nama_kategori']; ?></td>
                <td><?= $bk['tanggal_terbit']; ?></td>
                <td><?= $bk['jumlah_halaman']; ?></td>
                <td><?= $bk['nama_rak']; ?></td>
                <td><?= $bk['tanggal_pengadaan']; ?></td>
                <td><?= $bk['stok']; ?></td>
                <td><a href="<?= base_url(); ?>admin/hapusbuku/<?= $bk['kode_buku']; ?>" class="badge badge-danger float-right" onclick="return confirm('yakin ?');">Hapus</a>
                  <a href="<?= base_url(); ?>admin/ubahbuku/<?= $bk['kode_buku']; ?>" class="badge badge-success float-right">Ubah</a>
                  <a href="<?= base_url(); ?>admin/detailbuku/<?= $bk['kode_buku']; ?>" class="badge badge-primary float-right">Detail</a></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->