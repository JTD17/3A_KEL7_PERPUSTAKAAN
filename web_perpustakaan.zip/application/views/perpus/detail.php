<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Detail Penulis
                </div>
                <div class="card-body">
                    <h6 class="card-subtitle mb-2 text-muted">ID: <?= $penulis['kode_penulis']; ?></h6>
                    <h5 class="card-title"><?= $penulis['nama_penulis']; ?></h5>
                    <p class="card-text"><?= $penulis['alamat_penulis']; ?></p>
                    <p class="card-text"><?= $penulis['telp_penulis']; ?></p>
                    <a href="<?= base_url(); ?>admin/penulis" class="btn btn-primary">kembali</a>
                </div>
            </div>

        </div>
    </div>
</div>