<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Detail buku
                </div>
                <div class="card-body">
                    <h6 class="card-subtitle mb-2 text-muted">ID: <?= $buku['kode_buku']; ?></h6>
                    <h5 class="card-title"><?= $buku['judul_buku']; ?></h5>
                    <p class="card-text">ISBN: <?= $buku['isbn']; ?></p>
                    <p class="card-text">Penulis: <?= $buku['nama_penulis']; ?></p>
                    <p class="card-text">Penerbit: <?= $buku['nama_penerbit']; ?></p>
                    <p class="card-text">Kategori: <?= $buku['nama_kategori']; ?></p>
                    <p class="card-text">Tanggal Terbit: <?= $buku['tanggal_terbit']; ?></p>
                    <p class="card-text">Jumlah Halaman: <?= $buku['jumlah_halaman']; ?></p>
                    <p class="card-text">Rak: <?= $buku['nama_rak']; ?></p>
                    <p class="card-text">Tanggal Pengadaan: <?= $buku['tanggal_pengadaan']; ?></p>
                    <p class="card-text">Stok: <?= $buku['stok']; ?></p>
                    <a href="<?= base_url(); ?>admin/buku" class="btn btn-primary">kembali</a>
                </div>
            </div>

        </div>
    </div>
</div>