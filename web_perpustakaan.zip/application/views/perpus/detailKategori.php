<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Detail kategori
                </div>
                <div class="card-body">
                    <h6 class="card-subtitle mb-2 text-muted">ID: <?= $kategori['kode_kategori']; ?></h6>
                    <h5 class="card-title"><?= $kategori['nama_kategori']; ?></h5>
                    <a href="<?= base_url(); ?>admin/kategori" class="btn btn-primary">kembali</a>
                </div>
            </div>

        </div>
    </div>
</div>