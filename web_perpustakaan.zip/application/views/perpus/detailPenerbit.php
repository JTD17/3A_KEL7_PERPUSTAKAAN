<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Detail Penerbit
                </div>
                <div class="card-body">
                    <h6 class="card-subtitle mb-2 text-muted">ID: <?= $penerbit['kode_penerbit']; ?></h6>
                    <h5 class="card-title"><?= $penerbit['nama_penerbit']; ?></h5>
                    <p class="card-text"><?= $penerbit['alamat_penerbit']; ?></p>
                    <p class="card-text"><?= $penerbit['telp_penerbit']; ?></p>
                    <a href="<?= base_url(); ?>admin/penerbit" class="btn btn-primary">kembali</a>
                </div>
            </div>

        </div>
    </div>
</div>