<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Detail rak
                </div>
                <div class="card-body">
                    <h6 class="card-subtitle mb-2 text-muted">ID: <?= $rak['kode_rak']; ?></h6>
                    <h5 class="card-title"><?= $rak['nama_rak']; ?></h5>
                    <p class="card-text"><?= $rak['nama_kategori']; ?></p>
                    <a href="<?= base_url(); ?>admin/rak" class="btn btn-primary">kembali</a>
                </div>
            </div>

        </div>
    </div>
</div>