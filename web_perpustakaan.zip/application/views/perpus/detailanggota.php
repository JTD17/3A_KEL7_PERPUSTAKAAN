<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Detail Anggota
                </div>
                <div class="card-body">
                    <h6 class="card-subtitle mb-2 text-muted">Kode Anggota: <?= $anggota['kode_anggota']; ?></h6>
                    <h5 class="card-title"><?= $anggota['nama_anggota']; ?></h5>
                    <p class="card-text">Username:<?= $anggota['username_anggota']; ?></p>
                    <p class="card-text">Jenis Kelamin: <?= $anggota['jenis_kelamin']; ?></p>
                    <p class="card-text">Alamat: <?= $anggota['alamat_anggota']; ?></p>
                    <p class="card-text">Telepon: <?= $anggota['telp_anggota']; ?></p>
                    <p class="card-text">Tempat Lahir: <?= $anggota['tempat_lahir']; ?><p>
                            <p class="card-text">Tanggal Lahir: <?= $anggota['tanggal_lahir']; ?></p>
                            <p class="card-text">Tanggal Pendaftaran: <?= $anggota['tanggal_pendaftaran']; ?></p>
                            <a href="<?= base_url(); ?>admin/anggota" class="btn btn-primary">kembali</a>
                </div>
            </div>

        </div>
    </div>
</div>