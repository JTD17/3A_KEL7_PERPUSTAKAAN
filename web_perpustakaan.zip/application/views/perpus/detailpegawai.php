<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Detail Pegawai
                </div>
                <div class="card-body">
                    <h6 class="card-subtitle mb-2 text-muted">Kode Pegawai: <?= $pegawai['kode_pegawai']; ?></h6>
                    <h5 class="card-title"><?= $pegawai['nama_pegawai']; ?></h5>
                    <p class="card-text">Username:<?= $pegawai['username_pegawai']; ?></p>
                    <p class="card-text">Jenis Kelamin:<?= $pegawai['jenis_kelamin']; ?></p>
                    <p class="card-text">Alamat:<?= $pegawai['alamat_pegawai']; ?></p>
                    <p class="card-text">Telepon:<?= $pegawai['telp_pegawai']; ?></p>
                    <p class="card-text">Tempat Lahir:<?= $pegawai['tanggal_lahir']; ?><p>
                            <a href="<?= base_url(); ?>admin/pegawai" class="btn btn-primary">kembali</a>
                </div>
            </div>

        </div>
    </div>
</div>