<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Tabel Detail Transaksi</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Detail Transaksi</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Kode Transaksi</th>
                            <th>Judul Buku</th>
                            <th>Jumlah Buku</th>
                            <th>Tanggal Pinjam</th>
                            <th>Tanggal Kembali</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Kode Transaksi</th>
                            <th>Judul Buku</th>
                            <th>Jumlah Buku</th>
                            <th>Tanggal Pinjam</th>
                            <th>Tanggal Kembali</th>
                            <th>Status</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php foreach ($detail as $dtl) : ?>
                            <tr>
                                <td><?= $dtl['kode_transaksi']; ?></td>
                                <td><?= $dtl['judul_buku']; ?></td>
                                <td><?= $dtl['jumlah_buku']; ?></td>
                                <td><?= $dtl['tanggal_pinjam']; ?></td>
                                <td><?= $dtl['tanggal_kembali']; ?></td>
                                <td>
                                    <?php if ($dtl['status'] == 'Dipinjam') { ?>
                                        <div class="alert alert-primary" role="alert">
                                            <?= $dtl['status']; ?>
                                        </div>
                                    <?php } elseif ($dtl['status'] == 'Dikembalikan') { ?>
                                        <div class="alert alert-success" role="alert">
                                            <?= $dtl['status']; ?>
                                        </div>
                                    <?php } elseif ($dtl['status'] == 'Menunggu') { ?>
                                        <div class="alert alert-warning" role="alert">
                                            <?= $dtl['status']; ?>
                                        </div>
                                    <?php } else { ?>
                                        <div class="alert alert-danger" role="alert">
                                            <?= $dtl['status']; ?>
                                        </div>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->