<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Table Kategori</h1>
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Data Kategori</h6>
    </div>
    <div class="col-md-6 mt-3">
      <a href="<?= base_url(); ?>admin/tambahkategori" class="btn btn-primary">Tambah Data Kategori</a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Kode Kategori</th>
              <th>Nama Kategori</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>Kode Kategori</th>
              <th>Nama Kategori</th>
              <th>Action</th>

            </tr>
          </tfoot>
          <tbody>
            <?php foreach ($kategori as $ktgr) : ?>
              <tr>
                <td><?= $ktgr['kode_kategori']; ?></td>
                <td><?= $ktgr['nama_kategori']; ?></td>
                <td><a href="<?= base_url(); ?>admin/hapuskategori/<?= $ktgr['kode_kategori']; ?>" class="badge badge-danger float-right" onclick="return confirm('yakin ?');">Hapus</a>
                  <a href="<?= base_url(); ?>admin/ubahkategori/<?= $ktgr['kode_kategori']; ?>" class="badge badge-success float-right">Ubah</a>
                  <a href="<?= base_url(); ?>admin/detailkategori/<?= $ktgr['kode_kategori']; ?>" class="badge badge-primary float-right">Detail</a></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->