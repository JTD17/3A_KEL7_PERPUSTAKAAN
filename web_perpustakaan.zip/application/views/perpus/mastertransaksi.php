<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Tabel Master Transaksi</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Master Transaksi</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Kode Transaksi</th>
                            <th>Tanggal Transaksi</th>
                            <th>Nama Anggota</th>
                            <th>Nama Pegawai</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Kode Transaksi</th>
                            <th>Tanggal Transaksi</th>
                            <th>Nama Anggota</th>
                            <th>Nama Pegawai</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php foreach ($detail as $dtl) : ?>
                            <tr>
                                <td><?= $dtl['kode_transaksi']; ?></td>
                                <td><?= $dtl['tanggal_transaksi']; ?></td>
                                <td><?= $dtl['nama_anggota']; ?></td>
                                <td><?= $dtl['nama_pegawai']; ?></td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->