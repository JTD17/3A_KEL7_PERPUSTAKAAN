<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Table Pegawai</h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Pegawai</h6>
        </div>
        <div class="col-md-6 mt-3">
            <a href="<?= base_url(); ?>admin/tambahpegawai" class="btn btn-primary">Tambah Data pegawai</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Kode pegawai</th>
                            <th>Username </th>
                            <th>Nama pegawai</th>
                            <th>Jenis Kelamin</th>
                            <th>Alamat</th>
                            <th>Telepon</th>
                            <th>Tempat Lahir</th>
                            <th>Tanggal Lahir</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Kode pegawai</th>
                            <th>Username </th>
                            <th>Nama pegawai</th>
                            <th>Jenis Kelamin</th>
                            <th>Alamat</th>
                            <th>Telepon</th>
                            <th>Tempat Lahir</th>
                            <th>Tanggal Lahir</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php foreach ($pegawai as $peg) : ?>
                            <tr>
                                <td><?= $peg['kode_pegawai']; ?></td>
                                <td><?= $peg['username_pegawai']; ?></td>
                                <td><?= $peg['nama_pegawai']; ?></td>
                                <td><?= $peg['jenis_kelamin']; ?></td>
                                <td><?= $peg['alamat_pegawai']; ?></td>
                                <td><?= $peg['telp_pegawai']; ?></td>
                                <td><?= $peg['tempat_lahir']; ?></td>
                                <td><?= $peg['tanggal_lahir']; ?></td>
                                <td>
                                    <a href="<?= base_url(); ?>admin/detailpegawai/<?= $peg['kode_pegawai']; ?>" class="badge badge-primary float-right">Detail</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->